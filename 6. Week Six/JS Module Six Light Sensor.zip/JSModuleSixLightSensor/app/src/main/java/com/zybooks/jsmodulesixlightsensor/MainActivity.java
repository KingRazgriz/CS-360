package com.zybooks.jsmodulesixlightsensor;

import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.os.Bundle;
import android.widget.Button;
import android.widget.SeekBar;
import android.widget.TextView;
import android.util.Log;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity implements SensorEventListener {

    private SensorManager sensorManager;
    private Sensor lightSensor;
    private TextView lightValueText;
    private SeekBar lightSlider;
    private TextView simulatedValueText;
    private Button toggleSensorButton;

    private boolean useRealSensor = true;
    private float currentLightValue = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);

        // Set up window insets
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        // Initialize UI components
        lightValueText = findViewById(R.id.lightValueText);
        lightSlider = findViewById(R.id.lightSlider);
        simulatedValueText = findViewById(R.id.simulatedValueText);
        toggleSensorButton = findViewById(R.id.toggleSensorButton);

        // Initialize sensor components
        sensorManager = (SensorManager) getSystemService(SENSOR_SERVICE);
        if (sensorManager != null) {
            lightSensor = sensorManager.getDefaultSensor(Sensor.TYPE_LIGHT);
        }

        if (lightSensor == null) {
            lightValueText.setText("No light sensor available");
            toggleSensorButton.setEnabled(false);
            Log.e("LightSensor", "No light sensor detected");
        }

        // Set up slider
        lightSlider.setMax(10000); // 0-10,000 lux range
        lightSlider.setProgress(500); // Default to 500 lux
        lightSlider.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                currentLightValue = progress;
                simulatedValueText.setText(String.format("Simulated: %d lux", progress));
                if (!useRealSensor) {
                    updateLightDisplay(progress);
                }
            }

            @Override public void onStartTrackingTouch(SeekBar seekBar) {}
            @Override public void onStopTrackingTouch(SeekBar seekBar) {}
        });

        // Set up toggle button
        toggleSensorButton.setOnClickListener(v -> {
            useRealSensor = !useRealSensor;
            if (useRealSensor) {
                toggleSensorButton.setText("Use Simulated Light");
                if (lightSensor != null) {
                    sensorManager.registerListener(this, lightSensor, SensorManager.SENSOR_DELAY_NORMAL);
                }
            } else {
                toggleSensorButton.setText("Use Real Sensor");
                sensorManager.unregisterListener(this);
                updateLightDisplay((int)currentLightValue);
            }
        });
    }

    private void updateLightDisplay(float luxValue) {
        lightValueText.setText(String.format("Current light: %.2f lux", luxValue));
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (useRealSensor && lightSensor != null) {
            sensorManager.registerListener(this, lightSensor, SensorManager.SENSOR_DELAY_NORMAL);
        }
    }

    @Override
    protected void onPause() {
        super.onPause();
        sensorManager.unregisterListener(this);
    }

    @Override
    public void onSensorChanged(SensorEvent event) {
        if (useRealSensor && event.sensor.getType() == Sensor.TYPE_LIGHT) {
            currentLightValue = event.values[0];
            updateLightDisplay(currentLightValue);
            lightSlider.setProgress((int)currentLightValue);
            Log.d("LightSensor", "Current light level: " + currentLightValue + " lux");
        }
    }

    @Override
    public void onAccuracyChanged(Sensor sensor, int accuracy) {
        // Not used in this implementation
    }
}