package com.zybooks.js_projecttwo;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

public class DatabaseHelper extends SQLiteOpenHelper {

    private static final String TAG = "DatabaseHelper";
    private static final String DATABASE_NAME = "InventorySystem.db";
    private static final int DATABASE_VERSION = 2;

    // Users table and columns
    private static final String TABLE_USERS = "users";
    private static final String COLUMN_USER_ID = "user_id";
    private static final String COLUMN_USERNAME = "username";
    private static final String COLUMN_PASSWORD = "password";

    // Inventory table and columns
    private static final String TABLE_INVENTORY = "inventory";
    private static final String COLUMN_ITEM_ID = "item_id";
    private static final String COLUMN_ITEM_NAME = "item_name";
    private static final String COLUMN_QUANTITY = "quantity";
    private static final String COLUMN_PRICE = "price";
    private static final String COLUMN_USER_FK = "user_fk";

    // Index creation statements
    private static final String CREATE_USERNAME_INDEX =
            "CREATE INDEX idx_username ON " + TABLE_USERS + "(" + COLUMN_USERNAME + ")";
    private static final String CREATE_USER_FK_INDEX =
            "CREATE INDEX idx_user_fk ON " + TABLE_INVENTORY + "(" + COLUMN_USER_FK + ")";

    public DatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        try {
            db.beginTransaction();

            // Create tables
            db.execSQL("CREATE TABLE " + TABLE_USERS + "("
                    + COLUMN_USER_ID + " INTEGER PRIMARY KEY AUTOINCREMENT,"
                    + COLUMN_USERNAME + " TEXT UNIQUE NOT NULL,"
                    + COLUMN_PASSWORD + " TEXT NOT NULL)");

            db.execSQL("CREATE TABLE " + TABLE_INVENTORY + "("
                    + COLUMN_ITEM_ID + " INTEGER PRIMARY KEY AUTOINCREMENT,"
                    + COLUMN_ITEM_NAME + " TEXT NOT NULL,"
                    + COLUMN_QUANTITY + " INTEGER DEFAULT 0,"
                    + COLUMN_PRICE + " REAL DEFAULT 0.0,"
                    + COLUMN_USER_FK + " INTEGER NOT NULL,"
                    + "FOREIGN KEY(" + COLUMN_USER_FK + ") REFERENCES " + TABLE_USERS + "(" + COLUMN_USER_ID + "))");

            // Create indexes
            db.execSQL(CREATE_USERNAME_INDEX);
            db.execSQL(CREATE_USER_FK_INDEX);

            db.setTransactionSuccessful();
        } catch (Exception e) {
            Log.e(TAG, "Error creating database", e);
        } finally {
            db.endTransaction();
        }
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        try {
            db.beginTransaction();
            if (oldVersion < 2) {
                db.execSQL("DROP TABLE IF EXISTS " + TABLE_INVENTORY);
                db.execSQL("DROP INDEX IF EXISTS idx_user_fk");
                onCreate(db);
            }
            db.setTransactionSuccessful();
        } catch (Exception e) {
            Log.e(TAG, "Error upgrading database", e);
        } finally {
            db.endTransaction();
        }
    }

    // Column name getters
    public static String getColumnItemName() { return COLUMN_ITEM_NAME; }
    public static String getColumnQuantity() { return COLUMN_QUANTITY; }
    public static String getColumnPrice() { return COLUMN_PRICE; }
    public static String getColumnUserId() { return COLUMN_USER_FK; }

    // User management methods
    public long addUser(String username, String password) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COLUMN_USERNAME, username);
        values.put(COLUMN_PASSWORD, password);

        long userId = db.insert(TABLE_USERS, null, values);
        db.close();
        return userId;
    }

    public boolean checkUser(String username, String password) {
        SQLiteDatabase db = this.getReadableDatabase();
        String[] columns = {COLUMN_USER_ID};
        String selection = COLUMN_USERNAME + " = ? AND " + COLUMN_PASSWORD + " = ?";
        String[] selectionArgs = {username, password};

        Cursor cursor = db.query(TABLE_USERS, columns, selection, selectionArgs,
                null, null, null);
        boolean exists = cursor.getCount() > 0;
        cursor.close();
        db.close();
        return exists;
    }

    public boolean usernameExists(String username) {
        SQLiteDatabase db = this.getReadableDatabase();
        String[] columns = {COLUMN_USER_ID};
        String selection = COLUMN_USERNAME + " = ?";
        String[] selectionArgs = {username};

        Cursor cursor = db.query(TABLE_USERS, columns, selection, selectionArgs,
                null, null, null);
        boolean exists = cursor.getCount() > 0;
        cursor.close();
        db.close();
        return exists;
    }

    public int getUserId(String username) {
        SQLiteDatabase db = this.getReadableDatabase();
        String[] columns = {COLUMN_USER_ID};
        String selection = COLUMN_USERNAME + " = ?";
        String[] selectionArgs = {username};

        Cursor cursor = db.query(TABLE_USERS, columns, selection, selectionArgs,
                null, null, null);

        int userId = -1;
        if (cursor.moveToFirst()) {
            userId = cursor.getInt(cursor.getColumnIndexOrThrow(COLUMN_USER_ID));
        }
        cursor.close();
        db.close();
        return userId;
    }

    // Inventory management methods
    public long addInventoryItem(InventoryItem item) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COLUMN_ITEM_NAME, item.getName());
        values.put(COLUMN_QUANTITY, item.getQuantity());
        values.put(COLUMN_PRICE, item.getPrice());
        values.put(COLUMN_USER_FK, item.getUserId());

        long id = db.insert(TABLE_INVENTORY, null, values);
        db.close();
        return id;
    }

    public Cursor getAllItems(int userId) {
        SQLiteDatabase db = this.getReadableDatabase();
        String selection = COLUMN_USER_FK + " = ?";
        String[] selectionArgs = {String.valueOf(userId)};

        return db.query(TABLE_INVENTORY,
                null, selection, selectionArgs, null, null, COLUMN_ITEM_NAME + " ASC");
    }

    public InventoryItem getItemById(long itemId) {
        SQLiteDatabase db = this.getReadableDatabase();
        String selection = COLUMN_ITEM_ID + " = ?";
        String[] selectionArgs = {String.valueOf(itemId)};

        Cursor cursor = db.query(TABLE_INVENTORY,
                null, selection, selectionArgs, null, null, null);

        InventoryItem item = null;
        if (cursor.moveToFirst()) {
            item = new InventoryItem();
            item.setId(cursor.getLong(cursor.getColumnIndexOrThrow(COLUMN_ITEM_ID)));
            item.setName(cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_ITEM_NAME)));
            item.setQuantity(cursor.getInt(cursor.getColumnIndexOrThrow(COLUMN_QUANTITY)));
            item.setPrice(cursor.getDouble(cursor.getColumnIndexOrThrow(COLUMN_PRICE)));
            item.setUserId(cursor.getInt(cursor.getColumnIndexOrThrow(COLUMN_USER_FK)));
        }
        cursor.close();
        db.close();
        return item;
    }

    public boolean updateInventoryItem(InventoryItem item) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COLUMN_ITEM_NAME, item.getName());
        values.put(COLUMN_QUANTITY, item.getQuantity());
        values.put(COLUMN_PRICE, item.getPrice());

        int rowsAffected = db.update(TABLE_INVENTORY, values,
                COLUMN_ITEM_ID + " = ?", new String[]{String.valueOf(item.getId())});
        db.close();
        return rowsAffected > 0;
    }

    public boolean deleteInventoryItem(long itemId) {
        SQLiteDatabase db = this.getWritableDatabase();
        int rowsAffected = db.delete(TABLE_INVENTORY,
                COLUMN_ITEM_ID + " = ?", new String[]{String.valueOf(itemId)});
        db.close();
        return rowsAffected > 0;
    }

    public Cursor getLowInventoryItems(int threshold, int userId) {
        SQLiteDatabase db = this.getReadableDatabase();
        String selection = COLUMN_QUANTITY + " <= ? AND " + COLUMN_USER_FK + " = ?";
        String[] selectionArgs = {String.valueOf(threshold), String.valueOf(userId)};

        return db.query(TABLE_INVENTORY,
                null, selection, selectionArgs, null, null, COLUMN_QUANTITY + " ASC");
    }

    // Utility methods
    public static void closeCursor(Cursor cursor) {
        if (cursor != null && !cursor.isClosed()) {
            cursor.close();
        }
    }
}