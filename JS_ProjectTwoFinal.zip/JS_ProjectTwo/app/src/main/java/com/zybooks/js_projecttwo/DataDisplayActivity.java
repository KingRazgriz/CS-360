package com.zybooks.js_projecttwo;

import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.SimpleCursorAdapter;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class DataDisplayActivity extends AppCompatActivity {

    private DatabaseHelper dbHelper;
    private SimpleCursorAdapter adapter;
    private int userId;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_data_display);

        // Get user ID from intent
        userId = getIntent().getIntExtra("USER_ID", -1);
        if (userId == -1) {
            Toast.makeText(this, "User not authenticated", Toast.LENGTH_SHORT).show();
            finish();
            return;
        }

        // Initialize views
        final EditText itemNameEditText = findViewById(R.id.itemNameEditText);
        final EditText quantityEditText = findViewById(R.id.quantityEditText);
        final EditText priceEditText = findViewById(R.id.priceEditText);
        Button addButton = findViewById(R.id.addButton);
        Button smsButton = findViewById(R.id.smsButton);
        ListView itemsListView = findViewById(R.id.itemsListView);

        dbHelper = new DatabaseHelper(this);

        // Set up ListView
        refreshListView();

        // Add item button click listener
        addButton.setOnClickListener(v -> {
            String name = itemNameEditText.getText().toString().trim();
            String quantityStr = quantityEditText.getText().toString().trim();
            String priceStr = priceEditText.getText().toString().trim();

            if (name.isEmpty() || quantityStr.isEmpty() || priceStr.isEmpty()) {
                Toast.makeText(this, "Please fill all fields", Toast.LENGTH_SHORT).show();
                return;
            }

            try {
                int quantity = Integer.parseInt(quantityStr);
                double price = Double.parseDouble(priceStr);

                // Create new InventoryItem
                InventoryItem newItem = new InventoryItem();
                newItem.setName(name);
                newItem.setQuantity(quantity);
                newItem.setPrice(price);
                newItem.setUserId(userId);

                // Add to database
                long newId = dbHelper.addInventoryItem(newItem);

                if (newId != -1) {
                    Toast.makeText(this, "Item added successfully", Toast.LENGTH_SHORT).show();
                    refreshListView();
                    // Clear input fields
                    itemNameEditText.setText("");
                    quantityEditText.setText("");
                    priceEditText.setText("");
                    itemNameEditText.requestFocus();
                } else {
                    Toast.makeText(this, "Failed to add item", Toast.LENGTH_SHORT).show();
                }
            } catch (NumberFormatException e) {
                Toast.makeText(this, "Please enter valid numbers", Toast.LENGTH_SHORT).show();
            }
        });

        // SMS button click listener
        smsButton.setOnClickListener(v -> {
            Intent smsIntent = new Intent(this, SmsActivity.class);
            smsIntent.putExtra("USER_ID", userId);
            startActivity(smsIntent);
        });

        // Set up long click for item editing
        itemsListView.setOnItemLongClickListener((parent, view, position, id) -> {
            InventoryItem item = dbHelper.getItemById(id);
            if (item != null) {
                Intent editIntent = new Intent(DataDisplayActivity.this, AddEditItemActivity.class);
                editIntent.putExtra("ITEM_ID", item.getId());
                editIntent.putExtra("ITEM_NAME", item.getName());
                editIntent.putExtra("ITEM_QUANTITY", item.getQuantity());
                editIntent.putExtra("ITEM_PRICE", item.getPrice());
                editIntent.putExtra("USER_ID", userId);
                startActivityForResult(editIntent, 1);
            }
            return true;
        });

        // Set click listener for deletion
        itemsListView.setOnItemClickListener((parent, view, position, id) -> {
            if (dbHelper.deleteInventoryItem(id)) {
                Toast.makeText(this, "Item deleted", Toast.LENGTH_SHORT).show();
                refreshListView();
            } else {
                Toast.makeText(this, "Failed to delete item", Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void refreshListView() {
        Cursor cursor = dbHelper.getAllItems(userId);

        // Define the columns we want to display
        String[] fromColumns = {
                DatabaseHelper.getColumnItemName(),
                DatabaseHelper.getColumnQuantity(),
                DatabaseHelper.getColumnPrice()
        };

        // Define the View IDs for each column
        int[] toViews = {
                R.id.itemNameTextView,
                R.id.quantityTextView,
                R.id.priceTextView
        };

        // Create or update the adapter
        if (adapter == null) {
            adapter = new SimpleCursorAdapter(
                    this,
                    R.layout.item_row,
                    cursor,
                    fromColumns,
                    toViews,
                    0
            );
            ListView itemsListView = findViewById(R.id.itemsListView);
            itemsListView.setAdapter(adapter);
        } else {
            adapter.changeCursor(cursor);
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == 1 && resultCode == RESULT_OK) {
            refreshListView();
        }
    }

    @Override
    protected void onDestroy() {
        DatabaseHelper.closeCursor(adapter != null ? adapter.getCursor() : null);
        if (dbHelper != null) {
            dbHelper.close();
        }
        super.onDestroy();
    }
}