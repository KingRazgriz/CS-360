package com.zybooks.js_projecttwo;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class AddEditItemActivity extends AppCompatActivity {

    private EditText nameEditText, quantityEditText, priceEditText;
    private Button saveButton;
    private DatabaseHelper dbHelper;
    private long itemId = -1;
    private int userId;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_edit_item);

        dbHelper = new DatabaseHelper(this);
        nameEditText = findViewById(R.id.edit_item_name);
        quantityEditText = findViewById(R.id.edit_item_quantity);
        priceEditText = findViewById(R.id.edit_item_price);
        saveButton = findViewById(R.id.save_button);

        // Get user ID from intent
        userId = getIntent().getIntExtra("USER_ID", -1);
        if (userId == -1) {
            Toast.makeText(this, "User not authenticated", Toast.LENGTH_SHORT).show();
            finish();
            return;
        }

        // Check if we're editing an existing item
        if (getIntent().hasExtra("ITEM_ID")) {
            itemId = getIntent().getLongExtra("ITEM_ID", -1);
            nameEditText.setText(getIntent().getStringExtra("ITEM_NAME"));
            quantityEditText.setText(String.valueOf(getIntent().getIntExtra("ITEM_QUANTITY", 0)));
            priceEditText.setText(String.valueOf(getIntent().getDoubleExtra("ITEM_PRICE", 0.0)));
            setTitle("Edit Item");
        } else {
            setTitle("Add New Item");
        }

        saveButton.setOnClickListener(v -> saveItem());
    }

    private void saveItem() {
        String name = nameEditText.getText().toString().trim();
        String quantityStr = quantityEditText.getText().toString().trim();
        String priceStr = priceEditText.getText().toString().trim();

        if (name.isEmpty()) {
            Toast.makeText(this, "Please enter item name", Toast.LENGTH_SHORT).show();
            return;
        }

        int quantity;
        try {
            quantity = Integer.parseInt(quantityStr);
        } catch (NumberFormatException e) {
            Toast.makeText(this, "Please enter a valid quantity", Toast.LENGTH_SHORT).show();
            return;
        }

        double price;
        try {
            price = Double.parseDouble(priceStr);
        } catch (NumberFormatException e) {
            Toast.makeText(this, "Please enter a valid price", Toast.LENGTH_SHORT).show();
            return;
        }

        InventoryItem item = new InventoryItem();
        item.setName(name);
        item.setQuantity(quantity);
        item.setPrice(price);
        item.setUserId(userId);

        boolean success;
        if (itemId == -1) {
            // Add new item
            long newId = dbHelper.addInventoryItem(item);
            success = newId != -1;
        } else {
            // Update existing item
            item.setId(itemId);
            success = dbHelper.updateInventoryItem(item);
        }

        if (success) {
            setResult(RESULT_OK);
            finish();
        } else {
            Toast.makeText(this, "Operation failed", Toast.LENGTH_SHORT).show();
        }
    }

    @Override
    protected void onDestroy() {
        dbHelper.close();
        super.onDestroy();
    }
}